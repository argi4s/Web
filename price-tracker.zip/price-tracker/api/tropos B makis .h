 #include <avr/io.h>
 #include <avr/interrupt.h>
 #include <util/delay.h>

 #define ADC_MIN_DISTANCE 20


 int bpress= 0;
 int obstacle = 0;

 void adc_freerun_init() {
	 // Disable ADC0
	 ADC0.CTRLA &= ~(ADC_ENABLE_bm);
	 // Clear the interrupt flag
	 int intflags = ADC0.INTFLAGS;

	 // Free-Running mode, a new conversion cycle starts immediately after the previous finishes
	 ADC0.CTRLA |= ADC_FREERUN_bm;
	 
	 // Enable Interrupts for  Window Comparator Mode, based on the ADCO.WINLT and ADC0.CTRLE
	 ADC0.INTCTRL |= ADC_WCMP_bm;
	 
	 // Enable the ADC
	 ADC0.CTRLA |= ADC_ENABLE_bm;
	 // Start Conversion
	 ADC0.COMMAND |= ADC_STCONV_bm;
	 while(!(ADC0.INTFLAGS & ADC_RESRDY_bm));
 }


 int main(void)
 {
	 PORTD.DIR |= 0b00000111;
	 PORTD.OUT |= 0b00000111;
	 PORTF.PIN5CTRL |= PORT_PULLUPEN_bm | PORT_ISC_RISING_gc;
	 //Select 8-bit resolution for ADC
	 ADC0.CTRLA |= ADC_RESSEL_8BIT_gc;
	 
	 // Use one sample per conversion
	 ADC0.CTRLB |= ADC_SAMPNUM_ACC1_gc;
	 // Debug Mode, ADC0 will continue to run in Break Debug mode when the CPU is halted , ?¬?©?? ?¥?°?¥?®???£?§?³?§ ?£?©?? ???µ????;
	 ADC0.DBGCTRL |= ADC_DBGRUN_bm;

	 // Window Comparator Mode
	 // Set threshold value at 10
	 ADC0.WINLT = ADC_MIN_DISTANCE;
	 // Interrupt when RESULT < WINLT, meaning when the value of ADC0.RES is below the threshold in ADC0.WINLT
	 ADC0.CTRLE |= ADC_WINCM0_bm;

	 
	 
	 sei();

	 
	 

	 while (1)
	 {
		 if (obstacle == 0) // elegxos an uparxei empodio . ean oxi koitaei poses fores patithike to koumpi wste na kanei thn anstistixh leitourgia 
		 
		 
	 {
			 
			if (bpress% 3 == 0)  // an patithei 3 fores apenergopoieite o anemistiras entelws opote kanume disable olous tous kataxorites 
		 
		 {
		      TCB1.CTRLA &= ~(TCB_ENABLE_bm);
			  TCB2.CTRLA &= ~(TCB_ENABLE_bm);
			  ADC0.CTRLA &= ~(ADC_ENABLE_bm);

			 PORTD.OUTCLR= 0b00000000;
		 }
		 
		 else if ((bpress% 3) == 1 )  // otan patithei prwth fora anavume pera apto led 0,1,2 kai to 3 wste na katalavume oti einai se mode 1  . 
		 {
			 PORTD.OUTSET= 0b00001111;
			 
			
			 
			 adc_freerun_init(); // freefun mode wste na ginei elegxos gia empodio
			 
			 
		 }
		 
		 else if ((bpress% 3) == 2 ) // otan patithei deuterh fora anavume mono ta 3 prwta led . ara imaste se mode 2 
		 {
			 PORTD.OUTSET= 0b00000111;
			 adc_freerun_init(); // freerun mode wste na ginei elegxos gia empodio
			 
		 }
		 }
		 
		 else {  // gia na ftasei edw o kwdikas shmainei oti eixame vrei empodio dhladh obstacle =1 enw tautoxrona to res egine ksana > threshhold
			 // diaforetika tha pigene sunexeia sto interrupt tou ADC . ara den uparxei empodio kai o anemistiras kanei epanakinish 
			 // dhladh vazume ksana to obstacle 0 gia na bei sthn if twn leitourgiwn kai kanume enable TCB1 kai TCB2 ( eixan ginei disable sto interrupt tou ADC )   
			 
			 TCB1.CTRLA |= TCB_ENABLE_bm;
			 TCB2.CTRLA |= TCB_ENABLE_bm;
			 obstacle=0;
			 
		 }
		 
		 
		 
	 }
 }

 ISR(PORTF_PORT_vect){		//h arxikopoihsh  kai parametropoihsh twn kataxoritwn ginetai kata to patima tou koumpiou . 
	 //clear the interrupt flag
	 int y = PORTF.INTFLAGS;
	 PORTF.INTFLAGS=y;
	 bpress= bpress+1;		//
	 
	 	 
	 	 TCB1.CCMP = 0x2040; //blades - lepides,	Load CCMP register for TCB1 with the period and duty cycle of the PWM.
	 	 TCB2.CCMP = 0x3380; //base -bash, Load CCMP register for TCB2 with the period and duty cycle of the PWM.  
	 	 
		  // vazume ena mikro delay metaksi twn 2 counter wste na apofeuxthei ''sugroush '' twn palmwn kai na pigenume omala apto ena isr sto allo
		  
		 TCB1.CNT=0;
		 TCB2.CNT=5;
		  
		  
		  
	 	 TCB1.CTRLA |= TCB_ENABLE_bm;		//Enable the counter TCB1 by writing a ‘1’ to the ENABLE bit in the Control A (TCBn.CTRLA) register
	 	 TCB2.CTRLA |= TCB_ENABLE_bm;		//Enable the counter TCB2 by writing a ‘1’ to the ENABLE bit in the Control A (TCBn.CTRLA) register
	 	 TCB1.CTRLA |= TCB_CLKSEL_CLKDIV2_gc; //In order to get the lowest possible frequency, CLK_PER will be further divided by 2, õðïäéáßñåóç ôïõ CLK óôï ìéóü ãéá ôïí ÔØÂ1
	 	 TCB2.CTRLA |= TCB_CLKSEL_CLKDIV2_gc;  //In order to get the lowest possible frequency, CLK_PER will be further divided by 2, õðïäéáßñåóç ôïõ CLK óôï ìéóü ãéá ôïí ÔØÂ2
	 	 TCB1.CTRLB |= TCB_CCMPEN_bm;			//CCMPEN for TCB1 must be enabled
	 	 TCB2.CTRLB |= TCB_CCMPEN_bm;			//CCMPEN for TCB2 must be enabled
	 	 TCB1.CTRLB |= TCB_CNTMODE_PWM8_gc;		//TCB1 must be configured for the 8-bit PWM mode
	 	 TCB2.CTRLB |= TCB_CNTMODE_PWM8_gc;		//TCB2 must be configured for the 8-bit PWM mode
		 TCB1.INTCTRL = TCB_CAPT_bm;			//Enable Capture or Timeout interrupt for TCB1
		 TCB2.INTCTRL = TCB_CAPT_bm;			//Enable Capture or Timeout interrupt for TCB2
		  
	 if (y & bpress%3==2){
		 TCB1.CCMP = 0x4080;	// diplasiasmos ths periodou twn lepidwn kratontas to idio duty cycle tou 50%
		 TCB2.CCMP = 0x3380; //
	 }
 }


 ISR( TCB1_INT_vect ){		//blades- lepides anemistira. 
	 int x = TCB1.INTFLAGS;
	 TCB1.INTFLAGS = x;
	 
	 PORTD.OUTCLR= 0b00000001;
	 
 }


 ISR(TCB2_INT_vect ) {  //base - bash anemistira. 1
	 int intflags = TCB2.INTFLAGS;
	 TCB2.INTFLAGS = intflags;
	 PORTD.OUTCLR= 0b00000010;
 }



 ISR(ADC0_WCOMP_vect){		// isr gia to empodio . disable TCB1 kai TCB2  afou o anemistiras klinei . diaforetika tha pigenei sunexeia sta antistixa isr
	 // alla kratame to adc wste na ksanabenei sto idio ISR eos wtou na valume res < min distance
	 int intflags = ADC0.INTFLAGS;
	 ADC0.INTFLAGS = intflags;
	 PORTD.OUTCLR= 0b00000100;
	 TCB1.CTRLA &= ~(TCB_ENABLE_bm);
	 TCB2.CTRLA &= ~(TCB_ENABLE_bm);
	 obstacle=1;
 }
